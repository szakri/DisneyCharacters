package com.example.disneycharacters.ui.details

import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

//@AndroidEntryPoint
class DetailsViewModel @Inject constructor(private val detailsRepository: DetailsRepository) {
}