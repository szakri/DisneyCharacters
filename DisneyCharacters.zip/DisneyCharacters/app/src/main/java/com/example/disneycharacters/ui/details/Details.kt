package com.example.disneycharacters.ui.details

class Details {
}