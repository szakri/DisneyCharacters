package com.example.disneycharacters.ui.favorites

import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

//@AndroidEntryPoint
class FavoritesViewModel @Inject constructor(private val favoritesRepository: FavoritesRepository) {
}