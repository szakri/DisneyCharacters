package com.example.disneycharacters.ui.favorites

class Favorites {
}